package com.abarrotes.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {

    private static final String URL = "jdbc:mysql://localhost:3306/BD_Abarrotes";
    private static final String USER = "root";
    private static final String PASS = "301223";

    public static Connection conectar() {

        Connection con = null;

        try {

            con = DriverManager.getConnection(URL, USER, PASS);
            System.out.println("✅ Conexión exitosa");

        } catch (SQLException e) {

            System.out.println("❌ Error de conexión");
            e.printStackTrace();

        }

        return con;
    }
}
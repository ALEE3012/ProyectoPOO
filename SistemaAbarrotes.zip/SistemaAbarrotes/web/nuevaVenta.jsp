<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    // idUsuario de quien está logueado (Venta.idUsuario es NOT NULL).
    // Debe guardarse en la sesión al iniciar sesión, por ejemplo en el LoginServlet:
    //     session.setAttribute("idUsuario", rs.getInt("idUsuario"));
    Object idUsuarioSesion = session.getAttribute("idUsuario");
%>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Nueva Venta | La Casa del Gato</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;600;700&display=swap" rel="stylesheet">

<style>

:root{
    --oro:#D4AF37;
    --oro-suave:#f0c84b;
    --fondo:#0b0b0d;
    --panel:#141416;
    --panel-borde:rgba(212,175,55,.18);
    --texto:#f2f0ea;
    --texto-tenue:#9a978f;
    --exito:#3fae67;
    --alerta:#c0392b;
}

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Segoe UI',sans-serif;
}

body{
    min-height:100vh;
    background:var(--fondo);
    color:var(--texto);
    padding:30px 20px 60px;
}

h1,h2,h3{
    font-family:'Poppins',sans-serif;
}

.contenedor{
    max-width:960px;
    margin:auto;
}

.btn-regresar{
    display:inline-flex;
    align-items:center;
    gap:8px;
    margin-bottom:20px;
    padding:10px 18px;
    background:rgba(255,255,255,.06);
    border:1px solid var(--panel-borde);
    color:var(--texto);
    text-decoration:none;
    border-radius:10px;
    font-size:13.5px;
    transition:.2s;
}

.btn-regresar:hover{
    background:var(--oro);
    color:#0b0b0d;
    border-color:var(--oro);
}

.cabecera{
    display:flex;
    align-items:center;
    gap:12px;
    margin-bottom:24px;
}

.cabecera .icono{
    width:46px;
    height:46px;
    border-radius:12px;
    background:rgba(212,175,55,.12);
    color:var(--oro);
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:19px;
}

.cabecera h1{
    font-size:21px;
}

.cabecera p{
    font-size:12.5px;
    color:var(--texto-tenue);
    margin-top:2px;
}

.panel{
    background:var(--panel);
    border:1px solid var(--panel-borde);
    border-radius:16px;
    padding:24px;
    margin-bottom:20px;
}

.panel h2{
    font-size:15.5px;
    margin-bottom:6px;
    display:flex;
    align-items:center;
    gap:8px;
}

.panel h2 i{
    color:var(--oro);
    font-size:14px;
}

.panel .sub{
    font-size:12px;
    color:var(--texto-tenue);
    margin-bottom:18px;
}

.grid-2{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:14px;
}

.grid-4{
    display:grid;
    grid-template-columns:2fr 1.3fr 1fr 1fr .8fr auto;
    gap:12px;
    align-items:end;
}

.campo label{
    display:block;
    font-size:12px;
    color:var(--texto-tenue);
    margin-bottom:6px;
}

.campo input{
    width:100%;
    padding:11px 12px;
    border-radius:9px;
    border:1px solid var(--panel-borde);
    background:rgba(255,255,255,.05);
    color:var(--texto);
    font-size:13.5px;
    outline:none;
}

.campo input:focus{
    border-color:var(--oro);
}

.campo small{
    display:block;
    margin-top:5px;
    font-size:11px;
    color:var(--texto-tenue);
}

.btn-agregar{
    background:var(--oro);
    border:none;
    color:#0b0b0d;
    font-weight:600;
    font-size:13.5px;
    padding:11px 16px;
    border-radius:9px;
    cursor:pointer;
    white-space:nowrap;
    display:flex;
    align-items:center;
    justify-content:center;
    gap:8px;
    transition:.2s;
}

.btn-agregar:hover{
    background:var(--oro-suave);
}

/* tabla detalle */

.tabla-wrap{
    overflow-x:auto;
}

table{
    width:100%;
    border-collapse:collapse;
}

thead th{
    text-align:left;
    font-size:11.5px;
    letter-spacing:.5px;
    color:var(--texto-tenue);
    padding:0 12px 12px;
    border-bottom:1px solid var(--panel-borde);
}

tbody td{
    padding:12px;
    font-size:13.5px;
    border-bottom:1px solid rgba(255,255,255,.05);
}

tbody tr:last-child td{
    border-bottom:none;
}

.vacio td{
    text-align:center;
    color:var(--texto-tenue);
    padding:26px 12px;
    font-size:13px;
}

.btn-quitar{
    background:rgba(192,57,43,.14);
    color:#e2685c;
    border:none;
    width:30px;
    height:30px;
    border-radius:8px;
    cursor:pointer;
    font-size:12.5px;
}

.btn-quitar:hover{
    background:rgba(192,57,43,.3);
}

.resumen{
    display:flex;
    justify-content:flex-end;
    align-items:center;
    gap:14px;
    margin-top:18px;
    padding-top:18px;
    border-top:1px dashed var(--panel-borde);
}

.resumen span{
    font-size:13px;
    color:var(--texto-tenue);
}

.resumen strong{
    font-size:24px;
    color:var(--oro);
    font-family:'Poppins',sans-serif;
}

.botones-finales{
    display:flex;
    gap:12px;
    margin-top:22px;
}

.btn-guardar{
    flex:1;
    background:var(--oro);
    border:none;
    padding:13px;
    border-radius:10px;
    font-weight:700;
    font-size:14px;
    color:#0b0b0d;
    cursor:pointer;
    transition:.2s;
}

.btn-guardar:hover{
    background:var(--oro-suave);
    transform:translateY(-1px);
}

.btn-guardar:disabled{
    opacity:.4;
    cursor:not-allowed;
    transform:none;
}

.btn-limpiar{
    background:rgba(255,255,255,.06);
    border:1px solid var(--panel-borde);
    padding:13px 20px;
    border-radius:10px;
    color:var(--texto);
    font-size:13.5px;
    cursor:pointer;
}

.btn-limpiar:hover{
    border-color:#e2685c;
    color:#e2685c;
}

.mensaje-error{
    background:rgba(192,57,43,.14);
    border:1px solid rgba(192,57,43,.35);
    color:#e2685c;
    padding:12px 16px;
    border-radius:10px;
    font-size:13px;
    margin-bottom:18px;
}

@media(max-width:760px){
    .grid-2, .grid-4{
        grid-template-columns:1fr;
    }
}

</style>
</head>
<body>

<div class="contenedor">

    <a href="principal.jsp" class="btn-regresar">
        <i class="fa-solid fa-arrow-left"></i> Regresar al Dashboard
    </a>

    <div class="cabecera">
        <div class="icono"><i class="fa-solid fa-cart-plus"></i></div>
        <div>
            <h1>Nueva Venta</h1>
            <p>Registro manual — escribe los datos, no se elige de listas</p>
        </div>
    </div>

    <% if(idUsuarioSesion == null){ %>
    <div class="mensaje-error">
        No hay un usuario en sesión (idUsuario). Verifica que el LoginServlet guarde
        <code>session.setAttribute("idUsuario", ...)</code> al iniciar sesión — es obligatorio para registrar la venta.
    </div>
    <% } %>

    <form id="formVenta" action="VentaServlet" method="post">

        <input type="hidden" name="idUsuario" value="<%= idUsuarioSesion != null ? idUsuarioSesion : "" %>">

        <!-- ============ DATOS DEL CLIENTE (texto libre) ============ -->
        <div class="panel">
            <h2><i class="fa-solid fa-user"></i> Cliente</h2>
            <div class="sub">Si el cliente no existe todavía, el sistema lo registra automáticamente</div>

            <div class="grid-2">
                <div class="campo">
                    <label for="nombresCliente">Nombres</label>
                    <input type="text" id="nombresCliente" name="nombresCliente" placeholder="Ej. María José" required>
                </div>
                <div class="campo">
                    <label for="apellidosCliente">Apellidos</label>
                    <input type="text" id="apellidosCliente" name="apellidosCliente" placeholder="Ej. Torres Vega" required>
                </div>
                <div class="campo">
                    <label for="telefonoCliente">Teléfono</label>
                    <input type="text" id="telefonoCliente" name="telefonoCliente" placeholder="Opcional">
                </div>
                <div class="campo">
                    <label for="direccionCliente">Dirección</label>
                    <input type="text" id="direccionCliente" name="direccionCliente" placeholder="Opcional">
                </div>
            </div>
        </div>

        <!-- ============ AGREGAR PRODUCTO (texto libre) ============ -->
        <div class="panel">
            <h2><i class="fa-solid fa-boxes-stacked"></i> Productos</h2>
            <div class="sub">Si el producto no existe, se crea junto con su categoría y su registro en inventario</div>

            <div class="grid-4">

                <div class="campo">
                    <label for="nombreProducto">Producto</label>
                    <input type="text" id="nombreProducto" placeholder="Ej. Alimento Gato 3kg">
                </div>

                <div class="campo">
                    <label for="categoriaProducto">Categoría</label>
                    <input type="text" id="categoriaProducto" placeholder="Ej. Alimentos" value="General">
                </div>

                <div class="campo">
                    <label for="precioProducto">P. Venta</label>
                    <input type="number" id="precioProducto" step="0.01" min="0" placeholder="0.00">
                </div>

                <div class="campo">
                    <label for="cantProducto">Cantidad</label>
                    <input type="number" id="cantProducto" min="1" value="1">
                </div>

                <div class="campo">
                    <label for="precioCompraProducto">P. Compra</label>
                    <input type="number" id="precioCompraProducto" step="0.01" min="0" placeholder="Opcional">
                </div>

                <button type="button" class="btn-agregar" id="btnAgregar">
                    <i class="fa-solid fa-plus"></i> Agregar
                </button>

            </div>
            <small style="display:block;margin-top:10px;">El precio de compra es opcional; si lo dejas vacío, se guarda igual al precio de venta.</small>
        </div>

        <!-- ============ DETALLE ============ -->
        <div class="panel">
            <h2><i class="fa-solid fa-receipt"></i> Detalle de la venta</h2>

            <div class="tabla-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Producto</th>
                        <th>Categoría</th>
                        <th>Cantidad</th>
                        <th>P. Unitario</th>
                        <th>Subtotal</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody id="cuerpoDetalle">
                    <tr class="vacio" id="filaVacia">
                        <td colspan="6">Aún no agregaste productos a esta venta</td>
                    </tr>
                </tbody>
            </table>
            </div>

            <div class="resumen">
                <span>Total a pagar</span>
                <strong id="totalVenta">S/ 0.00</strong>
            </div>

            <!-- Campos ocultos que se envían al VentaServlet -->
            <div id="camposOcultos"></div>

        </div>

        <div class="botones-finales">
            <button type="submit" class="btn-guardar" id="btnGuardar">
                <i class="fa-solid fa-floppy-disk"></i> Guardar venta
            </button>
            <button type="button" class="btn-limpiar" id="btnLimpiar">Limpiar</button>
        </div>

    </form>

</div>

<script>

let items = [];

const nombreProducto      = document.getElementById('nombreProducto');
const categoriaProducto    = document.getElementById('categoriaProducto');
const precioProducto       = document.getElementById('precioProducto');
const cantProducto         = document.getElementById('cantProducto');
const precioCompraProducto = document.getElementById('precioCompraProducto');
const btnAgregar           = document.getElementById('btnAgregar');
const cuerpoDetalle        = document.getElementById('cuerpoDetalle');
const filaVacia            = document.getElementById('filaVacia');
const totalVenta           = document.getElementById('totalVenta');
const btnGuardar           = document.getElementById('btnGuardar');
const camposOcultos        = document.getElementById('camposOcultos');
const btnLimpiar           = document.getElementById('btnLimpiar');

function formatoSoles(n){
    return 'S/ ' + n.toFixed(2);
}

btnAgregar.addEventListener('click', () => {

    const nombre     = nombreProducto.value.trim();
    const categoria   = (categoriaProducto.value.trim() || 'General');
    const precio      = parseFloat(precioProducto.value);
    const cantidad    = parseInt(cantProducto.value) || 1;
    const precioCompra = precioCompraProducto.value.trim() === ''
        ? precio
        : parseFloat(precioCompraProducto.value);

    if(!nombre){
        nombreProducto.focus();
        return;
    }
    if(isNaN(precio) || precio <= 0){
        precioProducto.focus();
        return;
    }
    if(cantidad < 1){
        cantProducto.focus();
        return;
    }

    items.push({ nombre, categoria, precio, cantidad, precioCompra });

    nombreProducto.value = '';
    categoriaProducto.value = 'General';
    precioProducto.value = '';
    cantProducto.value = 1;
    precioCompraProducto.value = '';
    nombreProducto.focus();

    render();
});

function eliminar(indice){
    items.splice(indice, 1);
    render();
}

function render(){
    cuerpoDetalle.innerHTML = '';

    if(items.length === 0){
        cuerpoDetalle.appendChild(filaVacia);
        totalVenta.textContent = formatoSoles(0);
        camposOcultos.innerHTML = '';
        return;
    }

    let total = 0;
    let ocultosHTML = '';

    items.forEach((item, indice) => {
        const subtotal = item.precio * item.cantidad;
        total += subtotal;

        const fila = document.createElement('tr');
        fila.innerHTML = `
            <td>${item.nombre}</td>
            <td>${item.categoria}</td>
            <td>${item.cantidad}</td>
            <td>${formatoSoles(item.precio)}</td>
            <td>${formatoSoles(subtotal)}</td>
            <td><button type="button" class="btn-quitar" onclick="eliminar(${indice})">
                <i class="fa-solid fa-xmark"></i>
            </button></td>
        `;
        cuerpoDetalle.appendChild(fila);

        // arreglos paralelos que llegan al VentaServlet:
        // nombreProducto[], categoriaProducto[], cantidad[], precioVenta[], precioCompra[], subtotal[]
        ocultosHTML += `
            <input type="hidden" name="nombreProducto[]" value="${item.nombre}">
            <input type="hidden" name="categoriaProducto[]" value="${item.categoria}">
            <input type="hidden" name="cantidad[]" value="${item.cantidad}">
            <input type="hidden" name="precioVenta[]" value="${item.precio}">
            <input type="hidden" name="precioCompra[]" value="${item.precioCompra}">
            <input type="hidden" name="subtotal[]" value="${subtotal.toFixed(2)}">
        `;
    });

    camposOcultos.innerHTML = ocultosHTML;
    totalVenta.textContent = formatoSoles(total);
}

btnLimpiar.addEventListener('click', () => {
    items = [];
    document.getElementById('nombresCliente').value = '';
    document.getElementById('apellidosCliente').value = '';
    document.getElementById('telefonoCliente').value = '';
    document.getElementById('direccionCliente').value = '';
    render();
});

document.getElementById('formVenta').addEventListener('submit', (e) => {
    const nombresCliente = document.getElementById('nombresCliente').value.trim();
    const apellidosCliente = document.getElementById('apellidosCliente').value.trim();

    if(!nombresCliente || !apellidosCliente || items.length === 0){
        e.preventDefault();
        alert('Completa el nombre y apellido del cliente, y agrega al menos un producto.');
    }
});

</script>

</body>
</html>

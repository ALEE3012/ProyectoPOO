<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Dashboard | La Casa del Gato</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;600;700&family=Segoe+UI:wght@400;500&display=swap" rel="stylesheet">

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.4/chart.umd.min.js"></script>

<style>

:root{
    --oro:#D4AF37;
    --oro-suave:#f0c84b;
    --fondo:#0b0b0d;
    --panel:#141416;
    --panel-borde:rgba(212,175,55,.18);
    --texto:#f2f0ea;
    --texto-tenue:#9a978f;
    --exito:#3fae67;
    --alerta:#c0392b;
    --advertencia:#d99a1f;
}

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Segoe UI',sans-serif;
}

body{
    min-height:100vh;
    background:var(--fondo);
    color:var(--texto);
    display:flex;
}

h1,h2,h3,.marca{
    font-family:'Poppins',sans-serif;
}

/* ---------- SIDEBAR ---------- */

.sidebar{
    width:260px;
    min-height:100vh;
    background:#0a0a0b;
    border-right:1px solid var(--panel-borde);
    display:flex;
    flex-direction:column;
    position:fixed;
    top:0;
    left:0;
    z-index:20;
    transition:.3s;
}

.marca{
    display:flex;
    align-items:center;
    gap:12px;
    padding:26px 22px;
    border-bottom:1px solid var(--panel-borde);
}

.marca img{
    width:44px;
    height:44px;
    border-radius:50%;
    border:2px solid var(--oro);
    object-fit:cover;
}

.marca .txt{
    line-height:1.15;
}

.marca .txt span{
    display:block;
    font-size:10.5px;
    letter-spacing:1.5px;
    color:var(--texto-tenue);
    font-family:'Segoe UI',sans-serif;
}

.marca .txt strong{
    color:var(--oro);
    font-size:16px;
}

.nav{
    padding:18px 12px;
    flex:1;
}

.nav .grupo-titulo{
    font-size:11px;
    letter-spacing:1.5px;
    color:var(--texto-tenue);
    padding:14px 12px 8px;
}

.nav a{
    display:flex;
    align-items:center;
    gap:12px;
    padding:11px 14px;
    margin-bottom:4px;
    border-radius:10px;
    color:#cfcdc6;
    text-decoration:none;
    font-size:14.5px;
    position:relative;
    transition:.2s;
}

.nav a i{
    width:18px;
    text-align:center;
    color:var(--oro);
    opacity:.85;
}

.nav a:hover{
    background:rgba(212,175,55,.08);
    color:#fff;
}

.nav a.activo{
    background:linear-gradient(90deg,rgba(212,175,55,.18),rgba(212,175,55,.02));
    color:#fff;
    box-shadow:inset 3px 0 0 var(--oro);
}

.sidebar-pie{
    padding:16px 20px 22px;
    border-top:1px solid var(--panel-borde);
    display:flex;
    align-items:center;
    gap:10px;
}

.sidebar-pie img{
    width:36px;
    height:36px;
    border-radius:50%;
    border:2px solid var(--oro);
    object-fit:cover;
}

.sidebar-pie .u span{
    display:block;
    font-size:11px;
    color:var(--texto-tenue);
}

.sidebar-pie a{
    margin-left:auto;
    color:var(--texto-tenue);
    font-size:15px;
}

/* ---------- CONTENIDO ---------- */

.contenido{
    margin-left:260px;
    flex:1;
    min-height:100vh;
    display:flex;
    flex-direction:column;
}

.topbar{
    height:74px;
    display:flex;
    align-items:center;
    justify-content:space-between;
    padding:0 30px;
    border-bottom:1px solid var(--panel-borde);
    position:sticky;
    top:0;
    background:rgba(11,11,13,.85);
    backdrop-filter:blur(10px);
    z-index:15;
}

.topbar h1{
    font-size:19px;
    font-weight:600;
}

.topbar .fecha{
    font-size:12.5px;
    color:var(--texto-tenue);
    font-weight:400;
}

.buscador{
    display:flex;
    align-items:center;
    gap:10px;
    background:rgba(255,255,255,.05);
    border:1px solid var(--panel-borde);
    border-radius:10px;
    padding:9px 14px;
    width:320px;
}

.buscador input{
    background:transparent;
    border:none;
    outline:none;
    color:var(--texto);
    font-size:13.5px;
    width:100%;
}

.buscador i{
    color:var(--texto-tenue);
}

.topbar-acciones{
    display:flex;
    align-items:center;
    gap:18px;
}

.icono-campana{
    position:relative;
    color:var(--texto-tenue);
    font-size:17px;
    cursor:pointer;
}

.icono-campana .punto{
    position:absolute;
    top:-4px;
    right:-5px;
    width:8px;
    height:8px;
    background:var(--alerta);
    border-radius:50%;
    border:2px solid var(--fondo);
}

.btn-nuevo{
    background:var(--oro);
    color:#0b0b0d;
    border:none;
    padding:10px 18px;
    border-radius:10px;
    font-weight:600;
    font-size:13.5px;
    cursor:pointer;
    display:flex;
    align-items:center;
    gap:8px;
    transition:.2s;
}

.btn-nuevo:hover{
    background:var(--oro-suave);
    transform:translateY(-1px);
    box-shadow:0 6px 16px rgba(212,175,55,.25);
}

.zona{
    padding:28px 30px 40px;
}

/* ---------- TARJETAS KPI ---------- */

.kpis{
    display:grid;
    grid-template-columns:repeat(4,1fr);
    gap:20px;
    margin-bottom:26px;
}

.kpi{
    background:var(--panel);
    border:1px solid var(--panel-borde);
    border-radius:16px;
    padding:20px 22px;
    position:relative;
    overflow:hidden;
}

.kpi::before{
    content:"";
    position:absolute;
    top:0; right:0;
    width:90px;
    height:90px;
    background:radial-gradient(circle,rgba(212,175,55,.14),transparent 70%);
}

.kpi .fila-top{
    display:flex;
    justify-content:space-between;
    align-items:flex-start;
}

.kpi .icono{
    width:42px;
    height:42px;
    border-radius:11px;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:17px;
    background:rgba(212,175,55,.12);
    color:var(--oro);
}

.kpi.alerta .icono{
    background:rgba(192,57,43,.14);
    color:#e2685c;
}

.kpi .cambio{
    font-size:12px;
    font-weight:600;
    padding:4px 8px;
    border-radius:20px;
}

.cambio.pos{
    color:var(--exito);
    background:rgba(63,174,103,.12);
}

.cambio.neg{
    color:#e2685c;
    background:rgba(192,57,43,.12);
}

.kpi h3{
    font-size:26px;
    margin-top:16px;
    font-weight:700;
}

.kpi p{
    font-size:12.5px;
    color:var(--texto-tenue);
    margin-top:4px;
}

/* ---------- GRID PRINCIPAL ---------- */

.grid-principal{
    display:grid;
    grid-template-columns:1.6fr 1fr;
    gap:20px;
    margin-bottom:20px;
}

.panel{
    background:var(--panel);
    border:1px solid var(--panel-borde);
    border-radius:16px;
    padding:22px;
}

.panel-cabecera{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:18px;
}

.panel-cabecera h2{
    font-size:15.5px;
    font-weight:600;
}

.panel-cabecera .sub{
    font-size:12px;
    color:var(--texto-tenue);
    font-family:'Segoe UI',sans-serif;
    margin-top:2px;
}

.filtros-chip{
    display:flex;
    gap:6px;
}

.filtros-chip span{
    font-size:11.5px;
    padding:5px 11px;
    border-radius:20px;
    border:1px solid var(--panel-borde);
    color:var(--texto-tenue);
    cursor:pointer;
}

.filtros-chip span.activo{
    background:var(--oro);
    color:#0b0b0d;
    border-color:var(--oro);
    font-weight:600;
}

/* top productos */

.producto-fila{
    display:flex;
    align-items:center;
    gap:12px;
    padding:11px 0;
    border-bottom:1px solid rgba(255,255,255,.05);
}

.producto-fila:last-child{
    border-bottom:none;
}

.producto-icono{
    width:38px;
    height:38px;
    border-radius:10px;
    background:rgba(212,175,55,.1);
    color:var(--oro);
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:15px;
    flex-shrink:0;
}

.producto-info{
    flex:1;
}

.producto-info h4{
    font-size:13.5px;
    font-weight:500;
}

.barra-mini{
    height:5px;
    background:rgba(255,255,255,.06);
    border-radius:6px;
    margin-top:6px;
    overflow:hidden;
}

.barra-mini i{
    display:block;
    height:100%;
    background:linear-gradient(90deg,var(--oro),var(--oro-suave));
    border-radius:6px;
}

.producto-cifra{
    text-align:right;
    font-size:13px;
    font-weight:600;
    white-space:nowrap;
}

.producto-cifra span{
    display:block;
    font-size:11px;
    color:var(--texto-tenue);
    font-weight:400;
}

/* ---------- TABLAS ---------- */

.tabla-wrap{
    overflow-x:auto;
}

table{
    width:100%;
    border-collapse:collapse;
}

thead th{
    text-align:left;
    font-size:11.5px;
    letter-spacing:.6px;
    color:var(--texto-tenue);
    padding:0 14px 12px;
    font-weight:600;
    border-bottom:1px solid var(--panel-borde);
}

tbody td{
    padding:13px 14px;
    font-size:13.5px;
    border-bottom:1px solid rgba(255,255,255,.05);
}

tbody tr:last-child td{
    border-bottom:none;
}

tbody tr:hover{
    background:rgba(212,175,55,.04);
}

.cliente{
    display:flex;
    align-items:center;
    gap:10px;
}

.avatar-letra{
    width:32px;
    height:32px;
    border-radius:50%;
    background:rgba(212,175,55,.14);
    color:var(--oro);
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:12.5px;
    font-weight:700;
}

.badge{
    font-size:11.5px;
    font-weight:600;
    padding:5px 11px;
    border-radius:20px;
    white-space:nowrap;
}

.badge.completado{
    background:rgba(63,174,103,.14);
    color:var(--exito);
}

.badge.pendiente{
    background:rgba(217,154,31,.14);
    color:var(--advertencia);
}

.badge.stock-bajo{
    background:rgba(192,57,43,.14);
    color:#e2685c;
}

.badge.stock-agotado{
    background:rgba(192,57,43,.28);
    color:#ff9188;
}

.badge.stock-ok{
    background:rgba(63,174,103,.14);
    color:var(--exito);
}

.dos-columnas{
    display:grid;
    grid-template-columns:1.4fr 1fr;
    gap:20px;
}

.ver-todo{
    font-size:12.5px;
    color:var(--oro);
    text-decoration:none;
    font-weight:500;
}

/* responsive */

@media(max-width:1180px){
    .grid-principal, .dos-columnas{
        grid-template-columns:1fr;
    }
    .kpis{
        grid-template-columns:repeat(2,1fr);
    }
}

@media(max-width:860px){
    .sidebar{
        left:-260px;
    }
    .sidebar.abierto{
        left:0;
    }
    .contenido{
        margin-left:0;
    }
    .buscador{
        display:none;
    }
    .kpis{
        grid-template-columns:1fr;
    }
}

.btn-menu{
    display:none;
    color:var(--texto);
    font-size:19px;
    background:none;
    border:none;
    cursor:pointer;
}

@media(max-width:860px){
    .btn-menu{
        display:block;
    }
}

</style>
</head>
<body>

<!-- ================= SIDEBAR ================= -->
<aside class="sidebar" id="sidebar">

    <div class="marca">
        <img src="Img/logo.png.jpeg" alt="La Casa del Gato">
        <div class="txt">
            <strong>La Casa del Gato</strong>
            <span>GESTIÓN DE VENTAS</span>
        </div>
    </div>

    <nav class="nav">

        <div class="grupo-titulo">PRINCIPAL</div>
        <a href="#" class="activo"><i class="fa-solid fa-chart-pie"></i> Dashboard</a>

        <div class="grupo-titulo">OPERACIÓN</div>
        <a href="nuevaVenta.jsp"><i class="fa-solid fa-cash-register"></i> Ventas</a>
        <a href="#"><i class="fa-solid fa-boxes-stacked"></i> Inventario</a>
        <a href="#"><i class="fa-solid fa-truck-fast"></i> Compras / Proveedores</a>
        <a href="#"><i class="fa-solid fa-paw"></i> Productos</a>
        <a href="#"><i class="fa-solid fa-users"></i> Clientes</a>

        <div class="grupo-titulo">ANÁLISIS</div>
        <a href="#"><i class="fa-solid fa-file-invoice-dollar"></i> Reportes</a>
        <a href="#"><i class="fa-solid fa-gear"></i> Configuración</a>

    </nav>

    <div class="sidebar-pie">
        <img src="Img/logo.png.jpeg" alt="Usuario">
        <div class="u">
            <strong>Admin</strong>
            <span>Administrador</span>
        </div>
        <a href="LoginServlet?logout=true" title="Cerrar sesión">
            <i class="fa-solid fa-right-from-bracket"></i>
        </a>
    </div>

</aside>

<!-- ================= CONTENIDO ================= -->
<div class="contenido">

    <div class="topbar">

        <div style="display:flex;align-items:center;gap:16px;">
            <button class="btn-menu" onclick="document.getElementById('sidebar').classList.toggle('abierto')">
                <i class="fa-solid fa-bars"></i>
            </button>
            <div>
                <h1>Panel General</h1>
                <div class="fecha" id="fechaHoy"></div>
            </div>
        </div>

        <div class="buscador">
            <i class="fa-solid fa-magnifying-glass"></i>
            <input type="text" placeholder="Buscar producto, venta o cliente...">
        </div>

        <div class="topbar-acciones">
            <div class="icono-campana">
                <i class="fa-regular fa-bell"></i>
                <span class="punto"></span>
            </div>
            <button class="btn-nuevo">
                <i class="fa-solid fa-plus"></i> Nueva venta
            </button>
        </div>

    </div>

    <div class="zona">

        <!-- ============ KPIs ============ -->
        <div class="kpis">

            <div class="kpi">
                <div class="fila-top">
                    <div class="icono"><i class="fa-solid fa-sack-dollar"></i></div>
                    <span class="cambio pos"><i class="fa-solid fa-arrow-up"></i> 12.4%</span>
                </div>
                <h3>S/ 4,286.50</h3>
                <p>Ventas de hoy</p>
            </div>

            <div class="kpi">
                <div class="fila-top">
                    <div class="icono"><i class="fa-solid fa-receipt"></i></div>
                    <span class="cambio pos"><i class="fa-solid fa-arrow-up"></i> 8.1%</span>
                </div>
                <h3>57</h3>
                <p>Pedidos del mes</p>
            </div>

            <div class="kpi">
                <div class="fila-top">
                    <div class="icono"><i class="fa-solid fa-box"></i></div>
                    <span class="cambio pos"><i class="fa-solid fa-arrow-up"></i> 3.6%</span>
                </div>
                <h3>318</h3>
                <p>Productos activos</p>
            </div>

            <div class="kpi alerta">
                <div class="fila-top">
                    <div class="icono"><i class="fa-solid fa-triangle-exclamation"></i></div>
                    <span class="cambio neg"><i class="fa-solid fa-arrow-down"></i> Crítico</span>
                </div>
                <h3>9</h3>
                <p>Productos con stock bajo</p>
            </div>

        </div>

        <!-- ============ GRÁFICO + TOP PRODUCTOS ============ -->
        <div class="grid-principal">

            <div class="panel">
                <div class="panel-cabecera">
                    <div>
                        <h2>Ventas e ingresos</h2>
                        <div class="sub">Comparativo de los últimos 7 días</div>
                    </div>
                    <div class="filtros-chip">
                        <span class="activo">7D</span>
                        <span>30D</span>
                        <span>1A</span>
                    </div>
                </div>
                <canvas id="graficoVentas" height="150"></canvas>
            </div>

            <div class="panel">
                <div class="panel-cabecera">
                    <div>
                        <h2>Productos más vendidos</h2>
                        <div class="sub">Esta semana</div>
                    </div>
                </div>

                <div class="producto-fila">
                    <div class="producto-icono"><i class="fa-solid fa-fish"></i></div>
                    <div class="producto-info">
                        <h4>Alimento Gato Adulto 3kg</h4>
                        <div class="barra-mini"><i style="width:88%"></i></div>
                    </div>
                    <div class="producto-cifra">S/ 980<span>112 uds</span></div>
                </div>

                <div class="producto-fila">
                    <div class="producto-icono"><i class="fa-solid fa-bone"></i></div>
                    <div class="producto-info">
                        <h4>Snacks Dentales x10</h4>
                        <div class="barra-mini"><i style="width:71%"></i></div>
                    </div>
                    <div class="producto-cifra">S/ 640<span>96 uds</span></div>
                </div>

                <div class="producto-fila">
                    <div class="producto-icono"><i class="fa-solid fa-box-open"></i></div>
                    <div class="producto-info">
                        <h4>Arena Sanitaria 10L</h4>
                        <div class="barra-mini"><i style="width:63%"></i></div>
                    </div>
                    <div class="producto-cifra">S/ 512<span>64 uds</span></div>
                </div>

                <div class="producto-fila">
                    <div class="producto-icono"><i class="fa-solid fa-cat"></i></div>
                    <div class="producto-info">
                        <h4>Rascador Torre XL</h4>
                        <div class="barra-mini"><i style="width:44%"></i></div>
                    </div>
                    <div class="producto-cifra">S/ 385<span>11 uds</span></div>
                </div>

                <div class="producto-fila">
                    <div class="producto-icono"><i class="fa-solid fa-syringe"></i></div>
                    <div class="producto-info">
                        <h4>Vitaminas Multiuso</h4>
                        <div class="barra-mini"><i style="width:29%"></i></div>
                    </div>
                    <div class="producto-cifra">S/ 210<span>18 uds</span></div>
                </div>

            </div>

        </div>

        <!-- ============ TABLAS: VENTAS RECIENTES + INVENTARIO ============ -->
        <div class="dos-columnas">

            <div class="panel">
                <div class="panel-cabecera">
                    <div>
                        <h2>Ventas recientes</h2>
                        <div class="sub">Últimas transacciones registradas</div>
                    </div>
                    <a href="#" class="ver-todo">Ver todo</a>
                </div>

                <div class="tabla-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Cliente</th>
                            <th>Producto</th>
                            <th>Fecha</th>
                            <th>Total</th>
                            <th>Estado</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><div class="cliente"><div class="avatar-letra">MR</div>Milagros Rojas</div></td>
                            <td>Alimento Gato 3kg</td>
                            <td>02 Jul, 10:14</td>
                            <td>S/ 89.00</td>
                            <td><span class="badge completado">Completado</span></td>
                        </tr>
                        <tr>
                            <td><div class="cliente"><div class="avatar-letra">JC</div>Jorge Castillo</div></td>
                            <td>Arena Sanitaria 10L</td>
                            <td>02 Jul, 09:47</td>
                            <td>S/ 45.50</td>
                            <td><span class="badge completado">Completado</span></td>
                        </tr>
                        <tr>
                            <td><div class="cliente"><div class="avatar-letra">LP</div>Lucía Paredes</div></td>
                            <td>Rascador Torre XL</td>
                            <td>02 Jul, 09:20</td>
                            <td>S/ 129.90</td>
                            <td><span class="badge pendiente">Pendiente</span></td>
                        </tr>
                        <tr>
                            <td><div class="cliente"><div class="avatar-letra">AF</div>Andrea Flores</div></td>
                            <td>Snacks Dentales x10</td>
                            <td>01 Jul, 18:32</td>
                            <td>S/ 32.00</td>
                            <td><span class="badge completado">Completado</span></td>
                        </tr>
                        <tr>
                            <td><div class="cliente"><div class="avatar-letra">RS</div>Renzo Salas</div></td>
                            <td>Vitaminas Multiuso</td>
                            <td>01 Jul, 17:05</td>
                            <td>S/ 58.00</td>
                            <td><span class="badge pendiente">Pendiente</span></td>
                        </tr>
                    </tbody>
                </table>
                </div>
            </div>

            <div class="panel">
                <div class="panel-cabecera">
                    <div>
                        <h2>Alertas de inventario</h2>
                        <div class="sub">Productos que requieren reposición</div>
                    </div>
                    <a href="#" class="ver-todo">Ver todo</a>
                </div>

                <div class="tabla-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Producto</th>
                            <th>Stock</th>
                            <th>Estado</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Rascador Torre XL</td>
                            <td>3 uds</td>
                            <td><span class="badge stock-bajo">Stock bajo</span></td>
                        </tr>
                        <tr>
                            <td>Shampoo Antipulgas 250ml</td>
                            <td>0 uds</td>
                            <td><span class="badge stock-agotado">Agotado</span></td>
                        </tr>
                        <tr>
                            <td>Correa Retráctil M</td>
                            <td>4 uds</td>
                            <td><span class="badge stock-bajo">Stock bajo</span></td>
                        </tr>
                        <tr>
                            <td>Alimento Gatito 1kg</td>
                            <td>27 uds</td>
                            <td><span class="badge stock-ok">Disponible</span></td>
                        </tr>
                        <tr>
                            <td>Juguete Ratón x3</td>
                            <td>2 uds</td>
                            <td><span class="badge stock-bajo">Stock bajo</span></td>
                        </tr>
                    </tbody>
                </table>
                </div>
            </div>

        </div>

    </div>

</div>

<script>

document.getElementById('fechaHoy').textContent = new Date().toLocaleDateString('es-PE',{
    weekday:'long', year:'numeric', month:'long', day:'numeric'
});

const ctx = document.getElementById('graficoVentas').getContext('2d');
const gradiente = ctx.createLinearGradient(0,0,0,220);
gradiente.addColorStop(0,'rgba(212,175,55,.35)');
gradiente.addColorStop(1,'rgba(212,175,55,0)');

new Chart(ctx,{
    type:'line',
    data:{
        labels:['Lun','Mar','Mié','Jue','Vie','Sáb','Dom'],
        datasets:[{
            label:'Ingresos (S/)',
            data:[1280,1490,1120,1650,1980,2430,1785],
            borderColor:'#D4AF37',
            backgroundColor:gradiente,
            fill:true,
            tension:.4,
            pointBackgroundColor:'#D4AF37',
            pointBorderColor:'#0b0b0d',
            pointRadius:4,
            pointHoverRadius:6,
            borderWidth:2.5
        }]
    },
    options:{
        responsive:true,
        plugins:{ legend:{ display:false } },
        scales:{
            x:{
                grid:{ display:false },
                ticks:{ color:'#9a978f', font:{ size:11.5 } }
            },
            y:{
                grid:{ color:'rgba(255,255,255,.05)' },
                ticks:{ color:'#9a978f', font:{ size:11.5 },
                    callback:v => 'S/ ' + v }
            }
        },
        interaction:{ intersect:false, mode:'index' }
    }
});

</script>

</body>
</html>
